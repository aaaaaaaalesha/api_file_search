# Copyright 2021 aaaaaaaalesha

import pytest

from ..include.splay_tree import SplayTree

